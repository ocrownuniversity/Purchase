const CACHE_NAME = 'purchaselog-v3';

const ASSETS = [
  '/Purchase/',
  '/Purchase/index.html',
  '/Purchase/manifest.json',
  '/Purchase/icons/icon-72.png',
  '/Purchase/icons/icon-96.png',
  '/Purchase/icons/icon-128.png',
  '/Purchase/icons/icon-144.png',
  '/Purchase/icons/icon-152.png',
  '/Purchase/icons/icon-192.png',
  '/Purchase/icons/icon-384.png',
  '/Purchase/icons/icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  if (!event.request.url.startsWith('http')) return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200) return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => {
        if (event.request.mode === 'navigate') return caches.match('/Purchase/index.html');
      });
    })
  );
});

self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
